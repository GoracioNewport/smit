import pygame
import sys
import time
import numpy as np
from pygame.locals import *

width = 1920
height = 1080

class Bullet():
	def __init__(self, x, y, direction):
		self.x = x;
		self.y = y;
		self.radius = 4;
		self.direction = direction;
		self.speed = 10;
		self.imagePack = pygame.image.load("sprites/bullet.png")
		self.image = self.imagePack.subsurface(0, 0, 36, 9)
		if (self.direction == 0):
			self.image = pygame.transform.rotate(self.image, -90)
		if (self.direction == 1):
			self.image = pygame.transform.rotate(self.image, 0)
		if (self.direction == 2):
			self.image = pygame.transform.rotate(self.image, 90)
		if (self.direction == 3):
			self.image = pygame.transform.rotate(self.image, 180)

	def render(self, screen):
		screen.blit(self.image, (self.x, self.y))

	def move(self):
		if (self.direction == 0):
			self.y -= self.speed;
		if (self.direction == 1):
			self.x -= self.speed;
		if (self.direction == 2):
			self.y += self.speed;
		if (self.direction == 3):
			self.x += self.speed;

class Game():
	def __init__(self, screen):
		self.FPS = 60
		self.color = (255,255,255)
		self.bullets = []
		self.enemies = []

	def control(self):
		for event in pygame.event.get():
			if (event.type == pygame.QUIT):
				pygame.quit()
				sys.exit()
			if (event.type == KEYDOWN):


				if (event.key == K_UP):
					if (P.imageState == 1):
						P.image = pygame.transform.rotate(P.image, -90)
					if (P.imageState == 2):
						P.image = pygame.transform.rotate(P.image, -180)
					if (P.imageState == 3):
						P.image = pygame.transform.rotate(P.image, 90)
					P.imageState = 0;
					P.moveState = [0, 0, 0, 0]
					P.direction = 0;
					P.moveState[P.direction] = P.speed;


				if (event.key == K_LEFT):
					if (P.imageState == 0):
						P.image = pygame.transform.rotate(P.image, 90)
					if (P.imageState == 2):
						P.image = pygame.transform.rotate(P.image, -90)
					if (P.imageState == 3):
						P.image = pygame.transform.rotate(P.image, -180)
					P.imageState = 1;
					P.moveState = [0, 0, 0, 0]
					P.direction = 1;
					P.moveState[P.direction] = P.speed;


				if (event.key == K_DOWN):
					if (P.imageState == 0):
						P.image = pygame.transform.rotate(P.image, -180)
					if (P.imageState == 1):
						P.image = pygame.transform.rotate(P.image, 90)
					if (P.imageState == 3):
						P.image = pygame.transform.rotate(P.image, -90)
					P.imageState = 2;
					P.moveState = [0, 0, 0, 0]
					P.direction = 2;
					P.moveState[P.direction] = P.speed;


				if (event.key == K_RIGHT):
					if (P.imageState == 0):
						P.image = pygame.transform.rotate(P.image, -90)
					if (P.imageState == 1):
						P.image = pygame.transform.rotate(P.image, -180)
					if (P.imageState == 2):
						P.image = pygame.transform.rotate(P.image, 90)
					P.imageState = 3;
					P.moveState = [0, 0, 0, 0]
					P.direction = 3;
					P.moveState[P.direction] = P.speed;

				if (event.key == K_ESCAPE):
					pygame.quit()
					sys.exit()
				if (event.key == K_SPACE):
					sfxShoot.play()
					if (P.direction == 0):
						self.bullets.append(Bullet(P.x + P.radius - 4, P.y + P.radius - 18, P.direction))
					if (P.direction == 1):
						self.bullets.append(Bullet(P.x + P.radius - 18, P.y + P.radius - 4, P.direction))
					if (P.direction == 2):
						self.bullets.append(Bullet(P.x + P.radius - 4, P.y + P.radius - 18, P.direction))
					if (P.direction == 3):
						self.bullets.append(Bullet(P.x + P.radius - 18, P.y + P.radius - 4, P.direction))

				if (event.key == K_m):
					self.enemies.append(Enemy(300, 300, 1, 0))

				if (event.key == K_F4):
					pygame.display.toggle_fullscreen()
			
			if (event.type == KEYUP):
				if (event.key == K_UP):
					P.moveState[0] = 0;
				if (event.key == K_LEFT):
					P.moveState[1] = 0;
				if (event.key == K_DOWN):
					P.moveState[2] = 0;
				if (event.key == K_RIGHT):
					P.moveState[3] = 0;

	def render(self):
		P.render(screen)
		for i in range(len(self.bullets)):
			self.bullets[i].render(screen)
			self.bullets[i].move()
		for i in range(len(self.enemies)):
			self.enemies[i].render(screen)
			self.enemies[i].move()
		pygame.display.flip()

class Player():
	def __init__(self):
		self.x = width // 2;
		self.y = height // 2;
		self.color = (255, 0, 0)
		self.radius = 32;
		self.speed = 5;
		self.moveState = [0, 0, 0, 0];
		self.imagePack = pygame.image.load('sprites/player.png')
		self.image = self.imagePack.subsurface(0,0,64,64)
		self.imageState = 0;
		self.direction = 0; # 0 - UP, 1 - LEFT, 2 - DOWN, 3 - RIGHT

	def mainLoop(self):
		if (not self.collisionUp()):
			self.y -= self.moveState[0] # Up
		if (not self.collisionDown()):
			self.x -= self.moveState[1] # Left
		if (not self.collisionLeft()):
			self.y += self.moveState[2] # Down
		if (not self.collisionRight()):
			self.x += self.moveState[3] # Right

	def collisionUp(self):
		if (self.y - self.radius < 0):
			return True;
		else:
			return False;

	def collisionDown(self):
		if (self.y + self.radius + self.moveState[1] > height):
			return True;
		else:
			return False;

	def collisionLeft(self):
		if (self.x - self.radius - self.moveState[2] < 0):
			return True;
		else:
			return False;

	def collisionRight(self):
		if (self.x + self.radius + self.moveState[3] > width):
			return True;
		else:
			return False;

	def render(self, screen):
		screen.blit(self.image, (self.x, self.y))

class Enemy():
	def __init__(self, x, y, xSpeed, ySpeed):
		self.collided = False;
		self.x = x;
		self.y = y;
		self.radius = 16;
		self.xSpeed = xSpeed;
		self.ySpeed = ySpeed;
		self.imagePack = pygame.image.load('sprites/enemy.png')
		self.image = self.imagePack.subsurface(0,0,32,32)

	def collidedWithBullet(self):
		for x in range(len(G.bullets)):
			pass
		return self.collided;

	def render(self, screen):
		screen.blit(self.image, (self.x, self.y))
		if (self.collidedWithBullet):
			pass

	def move(self):
		self.x += self.xSpeed;
		self.y += self.ySpeed;

pygame.init()
pygame.mixer.init()
clock = pygame.time.Clock()

screen = pygame.display.set_mode((width, height))
pygame.display.toggle_fullscreen()
P = Player()
G = Game(screen)
pygame.display.update()
screen.fill(G.color)

pygame.mixer.music.load("sounds/background.mp3")
pygame.mixer.music.set_volume(1)
pygame.mixer.music.play()

sfxShoot = pygame.mixer.Sound("sounds/sfxShoot.wav")

while True:
	screen.fill(G.color)

	G.control()
	G.render()
	P.mainLoop()
	clock.tick(G.FPS)

	pygame.display.update()